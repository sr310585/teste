{
    "LeftAndMain.CONFIRMUNSAVED": "Kei te hiahia whakatere atu i tēnei whārangi?\n\nWHAKATŪPATO: Kāore anō ō huringa kia tiakina.\n\nPēhi AE kia haere tonu, Whakakore rānei kia noho i te whārangi onāianei.",
    "LeftAndMain.CONFIRMUNSAVEDSHORT": "WHAKATŪPATO: Kāore anō ō huringa kia tiakina.",
    "SecurityAdmin.BATCHACTIONSDELETECONFIRM": "Kei te tino hiahia muku i te %s rōpū?",
    "ModelAdmin.SAVED": "Kua Tiakina",
    "ModelAdmin.REALLYDELETE": "Kei te tino hiahia muku?",
    "ModelAdmin.DELETED": "Kua Mukua",
    "ModelAdmin.VALIDATIONERROR": "Hapa Whakamana",
    "LeftAndMain.PAGEWASDELETED": "I mukua tēnei whārangi.  Hei whakatika i tētahi whārangi, tīpakohia i te taha mauī."
}