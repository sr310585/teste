{
    "LeftAndMain.CONFIRMUNSAVED": "Siete sicuri di voler uscire da questa pagina?\n\nATTENZIONE: I vostri cambiamenti non sono stati salvati.\n\nCliccare OK per continuare, o su Annulla per rimanere sulla pagina corrente.",
    "LeftAndMain.CONFIRMUNSAVEDSHORT": "WARNING: Your changes have not been saved.",
    "SecurityAdmin.BATCHACTIONSDELETECONFIRM": "Do you really want to delete %s groups?",
    "ModelAdmin.SAVED": "Salvato",
    "ModelAdmin.REALLYDELETE": "Si è sicuri di voler eliminare?",
    "ModelAdmin.DELETED": "Eliminato",
    "ModelAdmin.VALIDATIONERROR": "Validation Error",
    "LeftAndMain.PAGEWASDELETED": "Questa pagina è stata eliminata. Per modificare questa pagine, selezionarla a sinistra."
}