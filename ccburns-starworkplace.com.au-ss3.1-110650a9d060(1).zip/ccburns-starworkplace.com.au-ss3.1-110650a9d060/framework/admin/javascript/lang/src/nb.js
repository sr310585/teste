{
    "LeftAndMain.CONFIRMUNSAVED": "Er du sikker på at du vil forlate denne siden?\n\nADVARSEL: Endringene din har ikke blitt lagret.\n\nTrykk OK for å fortsette eller Avbryt for å holde deg på samme side.",
    "LeftAndMain.CONFIRMUNSAVEDSHORT": "ADVARSEL: Endringene dine har ikke blitt lagret.",
    "SecurityAdmin.BATCHACTIONSDELETECONFIRM": "Vil du virkelig slette %s grupper?",
    "ModelAdmin.SAVED": "Lagret",
    "ModelAdmin.REALLYDELETE": "Vil du virkelig slette?",
    "ModelAdmin.DELETED": "Slettet",
    "ModelAdmin.VALIDATIONERROR": "Valideringsfeil",
    "LeftAndMain.PAGEWASDELETED": "Denne siden ble slettet. For å redigere en side, velg den fra listen til venstre."
}