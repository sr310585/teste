{
    "LeftAndMain.CONFIRMUNSAVED": "Sind Sie sicher, dass Sie die Seite verlassen möchten?\n\nWARNUNG: Ihre Änderungen werden nicht gespeichert.\n\nDrücken Sie \"OK\" um fortzufahren, oder \"Abbrechen\" um auf dieser Seite zu bleiben.",
    "LeftAndMain.CONFIRMUNSAVEDSHORT": "WARNUNG: Ihre Änderungen wurden nicht gespeichert.",
    "SecurityAdmin.BATCHACTIONSDELETECONFIRM": "Möchten Sie wirklich %s Gruppen löschen?",
    "ModelAdmin.SAVED": "Gespeichert",
    "ModelAdmin.REALLYDELETE": "Wirklich löschen?",
    "ModelAdmin.DELETED": "Gelöscht",
    "ModelAdmin.VALIDATIONERROR": "Validationsfehler",
    "LeftAndMain.PAGEWASDELETED": "Diese Seite wurde gelöscht."
}