<?php

/**
 * Used to locate configuration for a particular named service. 
 * 
 * If it isn't found, return null.
 *
 * @package framework
 * @subpackage injector
 */
class ServiceConfigurationLocator {
	public function locateConfigFor($name) {
		
	}
}