{
    "LeftAndMain.CONFIRMUNSAVED": "Да ли сте сигурни да желите да одете са ове странице?\n\nУПОЗОРЕЊЕ: Ваше измене још нису сачуване.\n\nПритисните У реду за наставак или Одустани да би сте остали на овој страници.",
    "LeftAndMain.CONFIRMUNSAVEDSHORT": "УПОЗОРЕЊЕ: Ваше измене нису сачуване.",
    "SecurityAdmin.BATCHACTIONSDELETECONFIRM": "Да ли заиста желите да се избришете %s групе?",
    "ModelAdmin.SAVED": "Сачувано.",
    "ModelAdmin.REALLYDELETE": "Да ли заиста желите да избришете?",
    "ModelAdmin.DELETED": "Избрисано",
    "ModelAdmin.VALIDATIONERROR": "Грешла при провери исправности",
    "LeftAndMain.PAGEWASDELETED": "Ова страница је избрисана. Да би изменили страницу, изаберите је са леве стране."
}