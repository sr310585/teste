{
    "LeftAndMain.CONFIRMUNSAVED": "Res želite zapusitit stran?\n\nOPOZORILO: spremembe niso bile shranjene\n\nKliknite OK za nadaljevanje ali Prekliči, da ostanete na trenutni strani.",
    "LeftAndMain.CONFIRMUNSAVEDSHORT": "OPOZORILO: spremembe niso bile shranjene.",
    "SecurityAdmin.BATCHACTIONSDELETECONFIRM": "Izbrišem %s skupin?",
    "ModelAdmin.SAVED": "Shranjeno",
    "ModelAdmin.REALLYDELETE": "Izbrišem?",
    "ModelAdmin.DELETED": "Izbrisano",
    "ModelAdmin.VALIDATIONERROR": "Napaka pri preverjanju",
    "LeftAndMain.PAGEWASDELETED": "Stran je bila izbrisana. Za urejanje izberite stran na levi."
}